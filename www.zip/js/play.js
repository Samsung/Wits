var playPageContainerElem = null;
var playPageTitleElem = null;
var progressBarElem = null;
var durationTimeElem = null;
var currentTimeElem = null;
var avplayControlElem = null;
var avplayLoadingElem = null;
var avplayLoadingTextElem = null;

var contentUrl = '';
var duration = 0;

const PLAY_ICON = './res/play.png'
const PAUSE_ICON = './res/pause.png'
const STATUS = {
    play : 'play',
    pause : 'pause',
}

function showPlayPage(contentData) {
    console.log('playPage',contentData);
    duration = 0;
    if(util.isRemoteUrl(contentData.src)) {
        contentUrl = contentData.src;
    } else {
        contentUrl = mountedPath + '/' + contentData.src;
    }
    
    console.log(contentUrl)
    renderPlayPage(contentData);
    setPlayPageKeyNavigation();
    playContent();
    changeControlState(STATUS.play);
}

function hidePlayPage() {
    webapis.avplay.close();
    playPageContainerElem.style.display = 'none';
    var avplayControlElem = document.getElementById('avplayControlElem');
    if(avplayControlElem) {
        keynav.removeListener(avplayControlElem, 'keydown', playPageKeyDownHandler);
    }
}

function renderPlayPage(contentData) {
    playPageContainerElem = util.createElement('div', {className: 'play-page-container', id: 'playPageContainerElem'});
    var avplayDisplayArea = util.createElement('object', {className: 'avplay-display', type: 'application/avplayer'});
    playPageContainerElem.appendChild(avplayDisplayArea);

    playPageTitleElem = util.createElement('div', {className: 'play-page title'}, contentData.title);
    playPageContainerElem.appendChild(playPageTitleElem);
    
    var progressInfoElem = util.createElement('div', {className: 'progress-info', id: 'progressInfoElem'});
    var progressElem = util.createElement('div', {className: 'play-progress'});
    progressBarElem = util.createElement('div', {className: 'play-progress-bar', id: 'progressBarElem'});
    progressElem.appendChild(progressBarElem);
    durationTimeElem = util.createElement('div', {className: 'duration-time', id: 'durationTimeElem'},'00:00:00');
    currentTimeElem = util.createElement('div', {className: 'current-time', id: 'currentTimeElem'},'00:00:00');
    progressInfoElem.appendChild(progressElem);
    progressInfoElem.appendChild(durationTimeElem);
    progressInfoElem.appendChild(currentTimeElem);
    playPageContainerElem.appendChild(progressInfoElem);

    avplayControlElem = util.createElement('img', {className: 'avplay-control nav-item', status: STATUS.pause, id: 'avplayControlElem'});
    playPageContainerElem.appendChild(avplayControlElem);

    avplayLoadingElem = util.createElement('div', {className: 'loading-container'});
    var avplayLoadingImgElem = util.createElement('div', {className: 'loading-img'});
    avplayLoadingTextElem = util.createElement('div', {className: 'loading-text', id:'avplayLoadingTextElem'},'0 %');
    avplayLoadingElem.appendChild(avplayLoadingImgElem);
    avplayLoadingElem.appendChild(avplayLoadingTextElem);
    playPageContainerElem.appendChild(avplayLoadingElem);
    
    changeControlState(STATUS.pause);
    document.body.appendChild(playPageContainerElem);
}

function setPlayPageKeyNavigation() {
    keynav.setLayerElement(playPageContainerElem);
    keynav.addListener(playPageContainerElem, 'keydown', playPageKeyDownHandler);
    bindPlayPageClickHandler();
};

function playPageKeyDownHandler(event, fromElement, toElement) {
    var keyName = keyCodeMap[event.keyCode];
    console.log(keyName);

    switch (keyName) {
        case 'LEFT':
            break;
        case 'RIGHT':
            break;
        case 'UP':
            break;
        case 'DOWN':
            break;
        case 'RETURN':
            hidePlayPage();
            showMainPage();
            break;
    }
    return {
        'focus': toElement
    };
}

function changeControlState(status) {
    var changedState = (status == STATUS.pause) ? STATUS.pause : STATUS.play;
    var iconImage = (changedState == STATUS.pause) ? PLAY_ICON : PAUSE_ICON;
    avplayControlElem.src = iconImage;
    avplayControlElem.setAttribute('status',changedState);
}

function bindPlayPageClickHandler () {
    var navElems = playPageContainerElem.getElementsByClassName('nav-item');
    for(var i=0; i < navElems.length; i++) {
        if(navElems[i].click) {
            navElems[i].addEventListener('click',playPageClickHandler);
        }
    }
}

function playPageClickHandler () {
    console.log('[play page] onClick Id: '+ event.target.id);
    var lastStatus = event.target.getAttribute('status');
    var currentStatus = '';

    if(lastStatus == STATUS.pause) {
        playContent();
        currentStatus = STATUS.play;
    }
    else {
        pauseContent();
        currentStatus = STATUS.pause;
    }
    changeControlState(currentStatus);
}

function playContent() {
    var state = webapis.avplay.getState();
    console.log('PlayerState : ', state);
    if(state == 'NONE' || state == 'IDLE') {
        webapis.avplay.open(contentUrl);
        webapis.avplay.setListener({
                onbufferingstart: function() {
                    console.log('onbufferingstart');
                    avplayLoadingElem.style.display = 'block';
                },
        
                onbufferingprogress: function(percent) {
                    console.log('onbufferingprogress', percent);
                    avplayLoadingTextElem.innerText = percent + ' %';
                },
        
                onbufferingcomplete: function() {
                    console.log('onbufferingcomplete');
                    avplayLoadingElem.style.display = 'none';
                },
        
                oncurrentplaytime: function(currentTime) {
                    console.log('oncurrentplaytime',currentTime);
                    currentTimeElem.innerText = getTimeString(currentTime);
                    var progress = parseInt((currentTime/duration) * 100);
                    progressBarElem.style.width = progress + '%';
                },
        
                onstreamcompleted: function() {
                    console.log('onstreamcompleted');
                    webapis.avplay.stop();
                    progressBarElem.style.width = '100%';
                    currentTimeElem.innerText = getTimeString(duration);
                    changeControlState(STATUS.pause);
                },
        
                onerror: function(errorType) {
                    console.log('onerror',errorType);
                }
        })
        webapis.avplay.setDisplayRect(0,0,1920,1080);
        webapis.avplay.prepareAsync(function() {
            webapis.avplay.play();
            duration = webapis.avplay.getDuration();
            durationTimeElem.innerText = getTimeString(duration);
        })
    }
    else if(state == 'PAUSED') {
        webapis.avplay.play();
    }
}

function pauseContent() {
    webapis.avplay.pause();
}

function getTimeString (ms) {
    var timeString = '';
    var hour = parseInt(ms/(3600*1000), 10);
    ms -= hour * (3600*1000);
    var min = parseInt(ms/(60*1000), 10);
    ms -= min * (60*1000);
    var sec = parseInt(ms/(1000), 10);
    timeString = (hour>9?hour:'0'+hour)+':'+(min>9?min:'0'+min)+':'+(sec>9?sec:'0'+sec);
    return timeString;
}
