var keyCodeMap = {
    37: 'LEFT',
    38: 'UP',
    39: 'RIGHT',
    40: 'DOWN',
    13: 'ENTER',
    27: 'RETURN',

    // Tizen TV
    10009: 'RETURN'
};

window.onload = function () {
    console.log('onload');
    startApp();
};

function initBodyTag() {
    document.body.innerHTML = '';
}

function startApp() {
    initBodyTag();
    var userData = JSON.parse(util.loadJSON('./data.json'));
    showMainPage(userData);
}
