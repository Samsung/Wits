/*
 * Copyright 2019 Samsung Electronics Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

var SUPPORTED_LAYOUTS = [
    'layout-1',
    'layout-2',
    'layout-3',
    'layout-4'
]

var mainPageContainerElem = null;
var mainPageTitleElem = null;
var descriptionElem = null;
var bgContentImgElem = null;
var contentsContainerElem = null;
var contentList = [];
var logoImage = '';
var layout = '';
var recentHighlightedElem = null;

function showMainPage(userData) {
    if(userData) {
        initMainPage();
        layout = userData.layout.toLowerCase();
        if(SUPPORTED_LAYOUTS.indexOf(layout) < 0 ) {
            layout = 'layout-1';
        }
        logoImage = userData.logoImage;
        contentList = userData.contents;
        console.log(contentList);
        renderMainPage();
    }
    else {
        mainPageContainerElem.style.display = 'block';
    }
    setMainPageKeyNavigation();
}

function initMainPage() {
    mainPageContainerElem = null;
    mainPageTitleElem = null;
    descriptionElem = null;
    bgContentImgElem = null;
    contentsContainerElem = null;
    contentList = [];
    logoImage = '';
    layout = '';
    recentHighlightedElem = null;
}

function hideMainPage() {
    mainPageContainerElem.style.display = 'none';
    var contentsContainerElem = document.getElementById('contentsContainerElem');
    if(contentsContainerElem) {
        keynav.removeListener(contentsContainerElem, 'keydown', mainPageKeyDownHandler);
    }
}

function clearPage() {
    document.body.innerHTML = '';
}

function renderMainPage() {
    var INITIAL_INDEX = 0;
    mainPageContainerElem = util.createElement('div', {className: 'main-page-container ' + layout, id: 'mainPageContainerElem'});
    var titleContainerElem = util.createElement('div', {className: 'title-container-elem ' + layout, id: 'mainPageTitleElem'});
    mainPageTitleElem = util.createElement('div', {id: 'title', className: 'title'},contentList[INITIAL_INDEX].title)
    descriptionElem = util.createElement('div', {id: 'description', className: 'description'},contentList[INITIAL_INDEX].desc)
    titleContainerElem.appendChild(mainPageTitleElem);
    titleContainerElem.appendChild(descriptionElem);
    mainPageContainerElem.appendChild(titleContainerElem);

    contentsContainerElem = util.createElement('div', {className: 'contents-container-elem ' + layout, tabIndex: '-1', id: 'contentsContainerElem'});
    if(contentList.length > 0) {
        for(var i=0; i < contentList.length; i++) {
            var contentElem = util.createElement('div', {className: 'content-item nav-item', index: i, id: 'contentElem_'+i});
            var imgElem = util.createElement('img', {className: 'content-image'});
            imgElem.src = contentList[i].thumbnail;
            contentElem.appendChild(imgElem);
            contentsContainerElem.appendChild(contentElem);
        }
        mainPageContainerElem.appendChild(contentsContainerElem);

        var bgContentElem = util.createElement('div', {className: 'bg-content ' + layout});
        bgContentImgElem = util.createElement('img', {className: 'bg-content-img-elem', id: 'bgContentImgElem'});
        bgContentElem.appendChild(bgContentImgElem);
        changeBackgroundImage(INITIAL_INDEX);
        mainPageContainerElem.appendChild(bgContentElem);
    } else {
        console.log('ContentList must has one or more content');
    }

    logoElem = util.createElement('img', {className: 'logo ' + layout, id: 'logoElem'});
    logoElem.src = logoImage;
    mainPageContainerElem.appendChild(logoElem);

    document.body.appendChild(mainPageContainerElem);
    contentsContainerElem.focus();
};

function setMainPageKeyNavigation() {
    keynav.setLayerElement(contentsContainerElem);
    if(recentHighlightedElem) {
        keynav.focusElement(recentHighlightedElem);
    }
    keynav.addListener(contentsContainerElem, 'keydown', mainPageKeyDownHandler);
    bindMainPageClickHandler();
    keynav.reload();
};

function changeBackgroundImage(index) {
    bgContentImgElem.src = contentList[index].bgImage;
}

function changeTitle(index) {
    mainPageTitleElem.innerText = contentList[index].title;
}

function changeDescription(index) {
    descriptionElem.innerText = contentList[index].desc;
}

function changeContentData(index) {
    changeBackgroundImage(index);
    changeTitle(index);
    changeDescription(index);
}

function mainPageKeyDownHandler (event, fromElement, toElement) {
    var keyName = keyCodeMap[event.keyCode];
    var parentElement = null;
    console.log(keyName);
    
    switch (keyName) {
        case 'LEFT':
            if(toElement) {
                parentElement = toElement.parentElement;
                if(util.getBoundingRect(toElement).left < util.getBoundingRect(parentElement).left) {
                    parentElement.scrollLeft = parentElement.scrollLeft - parseFloat(util.getBoundingRect(toElement,'margin').width);
                }
                changeContentData(toElement.getAttribute('index'));
            }
            event.preventDefault();
            break;
        case 'RIGHT':
            if(toElement) {
                parentElement = toElement.parentElement;
                if(util.getBoundingRect(toElement).right > util.getBoundingRect(parentElement).right) {
                    parentElement.scrollLeft = parentElement.scrollLeft + parseFloat(util.getBoundingRect(toElement,'margin').width);
                }
                changeContentData(toElement.getAttribute('index'));
            }
            event.preventDefault();
            break;
        case 'UP':
            if(toElement) {
                parentElement = toElement.parentElement;
                if(util.getBoundingRect(toElement).top < util.getBoundingRect(parentElement).top) {
                    parentElement.scrollTop = parentElement.scrollTop - parseFloat(util.getBoundingRect(toElement,'margin').height);
                }
                changeContentData(toElement.getAttribute('index'));
            }
            event.preventDefault();
            break;
        case 'DOWN':
            if(toElement) {
                parentElement = toElement.parentElement;
                if(util.getBoundingRect(toElement).bottom > util.getBoundingRect(parentElement).bottom) {
                    parentElement.scrollTop = parentElement.scrollTop + parseFloat(util.getBoundingRect(toElement,'margin').height);
                }
                changeContentData(toElement.getAttribute('index'));
            }
            event.preventDefault();
            break;
        case 'RETURN':
            tizen.application.getCurrentApplication().exit();
            break;
    }
    return {
        'focus': toElement
    };
}

function bindMainPageClickHandler() {
    var navElems = contentsContainerElem.getElementsByClassName('nav-item');
    for(var i=0; i < navElems.length; i++) {
        if(navElems[i].click) {
            navElems[i].addEventListener('click',mainPageClickHandler);
        }
    }
}

function mainPageClickHandler () {
    console.log('[main page]onClick Id: '+ event.target.id);
    recentHighlightedElem = event.target;
    showPlayPage(contentList[event.target.getAttribute('index')]);
    hideMainPage();
}